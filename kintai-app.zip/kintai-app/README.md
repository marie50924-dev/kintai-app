# 勤怠管理システム

FirebaseとReactで作られた勤怠管理アプリです。

## セットアップ

```bash
npm install
npm start
```

## デプロイ（Vercel）

1. このフォルダをGitHubにアップロード
2. vercel.com でGitHubリポジトリをインポート
3. デプロイ完了！

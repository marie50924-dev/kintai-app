import { useState, useEffect } from "react";
import {
  collection, doc, onSnapshot, setDoc, deleteDoc,
  updateDoc, addDoc, query, orderBy
} from "firebase/firestore";
import { db } from "./firebase";

const ADMIN_PASSWORD = "1234";
const DAYS_JP = ["日","月","火","水","木","金","土"];
const AVATAR_COLORS = [
  "#2563eb","#0891b2","#0284c7","#6366f1","#7c3aed",
  "#059669","#d97706","#dc2626","#db2777","#0d9488",
];

const fmt = {
  time: iso => iso ? new Date(iso).toLocaleTimeString("ja-JP",{hour:"2-digit",minute:"2-digit"}) : "--:--",
  date: iso => { const d=new Date(iso); return `${d.getMonth()+1}/${d.getDate()}(${DAYS_JP[d.getDay()]})`; },
  mins: m => { if(!m)return"0:00"; return `${Math.floor(m/60)}:${String(m%60).padStart(2,"0")}`; },
  yen: n => `¥${Math.round(n).toLocaleString()}`,
};

function workMins(clockIn, clockOut, breakMins=0) {
  if(!clockIn||!clockOut) return 0;
  return Math.max(0, Math.floor((new Date(clockOut)-new Date(clockIn))/60000)-breakMins);
}
function initials(name) {
  const p=name.trim().split(/\s+/);
  return p.length>=2 ? p[0][0]+p[1][0] : name.slice(0,2);
}

async function calcSalaryWithAI(emp, records, month) {
  const monthRecs = records.filter(r=>r.empId===emp.id && r.date.startsWith(month) && r.clockOut);
  const totalMins = monthRecs.reduce((a,r)=>a+workMins(r.clockIn,r.clockOut,r.breakMins),0);
  const totalHours = totalMins/60;
  const workDays = new Set(monthRecs.map(r=>r.date)).size;
  const prompt = `あなたは日本の給与計算の専門家です。以下の情報をもとに給与明細を計算してください。
【社員情報】名前: ${emp.name} / 基本給: ${emp.basicSalary}円 / 扶養: ${emp.dependents}人 / 時給: ${emp.hourlyRate}円
【${month}勤務実績】出勤: ${workDays}日 / 総労働: ${fmt.mins(totalMins)}（${totalHours.toFixed(2)}時間）/ 所定160時間
必ずJSON形式のみで返答（説明文不要）:
{"grossSalary":数値,"overtimePay":数値,"healthInsurance":数値,"pensionInsurance":数値,"employmentInsurance":数値,"incomeTax":数値,"residentTax":数値,"totalDeduction":数値,"netSalary":数値,"workDays":数値,"totalHours":"文字列","overtimeHours":数値,"memo":"メモ"}`;
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method:"POST",
    headers:{"Content-Type":"application/json","anthropic-dangerous-direct-browser-access":"true"},
    body: JSON.stringify({ model:"claude-sonnet-4-20250514", max_tokens:1000, messages:[{role:"user",content:prompt}] })
  });
  const d = await res.json();
  const text = d.content.map(c=>c.text||"").join("");
  return JSON.parse(text.replace(/```json|```/g,"").trim());
}

export default function App() {
  const [employees, setEmployees] = useState([]);
  const [records, setRecords] = useState([]);
  const [actives, setActives] = useState({});
  const [loaded, setLoaded] = useState(false);
  const [tab, setTab] = useState("clock");
  const [now, setNow] = useState(new Date());
  const [selEmpId, setSelEmpId] = useState(null);
  const [stampNote, setStampNote] = useState("");
  const [corrModal, setCorrModal] = useState(null);
  const [pwModal, setPwModal] = useState(null);
  const [pwInput, setPwInput] = useState("");
  const [pwError, setPwError] = useState("");
  const [histFilter, setHistFilter] = useState("all");
  const [selMonth, setSelMonth] = useState(()=>{ const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`; });
  const [monthEmpId, setMonthEmpId] = useState("all");
  const [newEmp, setNewEmp] = useState({name:"",dept:"",basicSalary:"",hourlyRate:"",dependents:"0"});
  const [empError, setEmpError] = useState("");
  const [editingEmp, setEditingEmp] = useState(null);
  const [salMonth, setSalMonth] = useState(()=>{ const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`; });
  const [salEmpId, setSalEmpId] = useState(null);
  const [salResult, setSalResult] = useState(null);
  const [salLoading, setSalLoading] = useState(false);
  const [salError, setSalError] = useState("");

  useEffect(()=>{ const t=setInterval(()=>setNow(new Date()),1000); return()=>clearInterval(t); },[]);

  useEffect(()=>{
    const u1=onSnapshot(collection(db,"employees"), s=>setEmployees(s.docs.map(d=>({id:d.id,...d.data()}))));
    const u2=onSnapshot(query(collection(db,"records"),orderBy("clockIn","desc")), s=>setRecords(s.docs.map(d=>({id:d.id,...d.data()}))));
    const u3=onSnapshot(collection(db,"actives"), s=>{ const a={}; s.docs.forEach(d=>{ a[d.id]=d.data(); }); setActives(a); setLoaded(true); });
    return()=>{ u1(); u2(); u3(); };
  },[]);

  function requirePw(cb){ setPwInput(""); setPwError(""); setPwModal({cb}); }
  function confirmPw(){ if(pwInput===ADMIN_PASSWORD){ setPwModal(null); pwModal.cb(); } else setPwError("パスワードが違います"); }

  async function doClockIn(){ if(!selEmpId||actives[String(selEmpId)]) return; const rec={empId:selEmpId,date:new Date().toISOString().slice(0,10),clockIn:new Date().toISOString(),clockOut:null,breakMins:0,note:""}; await setDoc(doc(db,"actives",String(selEmpId)),{rec,breakStart:null,totalBreak:0}); }
  async function doBreakStart(){ const a=actives[String(selEmpId)]; if(!a||a.breakStart) return; await updateDoc(doc(db,"actives",String(selEmpId)),{breakStart:new Date().toISOString()}); }
  async function doBreakEnd(){ const a=actives[String(selEmpId)]; if(!a?.breakStart) return; const added=Math.floor((now-new Date(a.breakStart))/60000); await updateDoc(doc(db,"actives",String(selEmpId)),{breakStart:null,totalBreak:(a.totalBreak||0)+added}); }
  async function doClockOut(){ const a=actives[String(selEmpId)]; if(!a) return; let bTotal=a.totalBreak||0; if(a.breakStart) bTotal+=Math.floor((now-new Date(a.breakStart))/60000); await addDoc(collection(db,"records"),{...a.rec,clockOut:new Date().toISOString(),breakMins:bTotal,note:stampNote}); await deleteDoc(doc(db,"actives",String(selEmpId))); setStampNote(""); }

  function currWorkMins(empId){ const a=actives[String(empId)]; if(!a) return 0; const el=Math.floor((now-new Date(a.rec.clockIn))/60000); const bu=(a.totalBreak||0)+(a.breakStart?Math.floor((now-new Date(a.breakStart))/60000):0); return Math.max(0,el-bu); }

  async function saveCorrected(rec){ if(rec.id&&records.find(r=>r.id===rec.id)){ const{id,...data}=rec; await setDoc(doc(db,"records",id),data); } else { const{id:_,...data}=rec; await addDoc(collection(db,"records"),{...data,corrected:true}); } setCorrModal(null); }

  async function addEmployee(){ const name=newEmp.name.trim(); if(!name){setEmpError("名前は必須です");return;} if(employees.find(e=>e.name===name)){setEmpError("同じ名前が既にいます");return;} const sal=parseInt(newEmp.basicSalary)||250000; await addDoc(collection(db,"employees"),{name,dept:newEmp.dept.trim(),basicSalary:sal,hourlyRate:parseInt(newEmp.hourlyRate)||Math.round(sal/160),dependents:parseInt(newEmp.dependents)||0,colorIdx:employees.length%AVATAR_COLORS.length}); setNewEmp({name:"",dept:"",basicSalary:"",hourlyRate:"",dependents:"0"}); setEmpError(""); }
  async function saveEditEmp(){ const{id,...data}=editingEmp; await setDoc(doc(db,"employees",id),{...data,basicSalary:parseInt(data.basicSalary)||250000,hourlyRate:parseInt(data.hourlyRate)||Math.round((parseInt(data.basicSalary)||250000)/160),dependents:parseInt(data.dependents)||0}); setEditingEmp(null); }
  async function removeEmployee(id){ requirePw(async()=>{ await deleteDoc(doc(db,"employees",id)); await deleteDoc(doc(db,"actives",String(id))); }); }

  async function calcSalary(){ if(!salEmpId){setSalError("社員を選択してください");return;} const emp=employees.find(e=>e.id===salEmpId); if(!emp)return; setSalLoading(true);setSalResult(null);setSalError(""); try{ const r=await calcSalaryWithAI(emp,records,salMonth); setSalResult({...r,empName:emp.name}); }catch(e){setSalError("計算エラー: "+e.message);} setSalLoading(false); }

  const active=selEmpId?actives[String(selEmpId)]:null;
  const isOnBreak=!!active?.breakStart;
  const selEmp=selEmpId?employees.find(e=>e.id===selEmpId):null;
  const histRecs=histFilter==="all"?records:records.filter(r=>r.empId===histFilter);
  const monthRecs=records.filter(r=>r.date?.startsWith(selMonth)&&(monthEmpId==="all"||r.empId===monthEmpId));
  const monthTotal=monthRecs.reduce((a,r)=>a+workMins(r.clockIn,r.clockOut,r.breakMins),0);
  const monthDays=new Set(monthRecs.filter(r=>r.clockOut).map(r=>r.date)).size;

  const C={bg:"#f0f7ff",surface:"#ffffff",surfaceAlt:"#f8faff",border:"#dbeafe",borderMd:"#bfdbfe",primary:"#2563eb",primaryDark:"#1d4ed8",primaryLight:"#eff6ff",primaryMid:"#dbeafe",text:"#1e3a5f",textSub:"#64748b",textMute:"#94a3b8",success:"#059669",warn:"#d97706",danger:"#dc2626",info:"#0891b2"};
  const css={
    card:{background:C.surface,border:`1px solid ${C.border}`,borderRadius:16,padding:"18px 20px",boxShadow:"0 2px 12px rgba(37,99,235,0.06)"},
    input:{width:"100%",padding:"11px 14px",boxSizing:"border-box",background:C.surfaceAlt,border:`1.5px solid ${C.border}`,borderRadius:10,color:C.text,fontSize:14,fontFamily:"inherit",outline:"none"},
    select:{width:"100%",padding:"11px 14px",boxSizing:"border-box",background:C.surfaceAlt,border:`1.5px solid ${C.border}`,borderRadius:10,color:C.text,fontSize:14,fontFamily:"inherit",outline:"none"},
    btnPrimary:{width:"100%",padding:"14px",borderRadius:12,border:"none",cursor:"pointer",background:`linear-gradient(135deg,${C.primary},${C.primaryDark})`,color:"#fff",fontSize:15,fontWeight:700,fontFamily:"inherit",boxShadow:"0 4px 14px rgba(37,99,235,0.3)"},
    btnSuccess:{width:"100%",padding:"14px",borderRadius:12,border:"none",cursor:"pointer",background:"linear-gradient(135deg,#059669,#047857)",color:"#fff",fontSize:15,fontWeight:700,fontFamily:"inherit",boxShadow:"0 4px 14px rgba(5,150,105,0.3)"},
    btnDanger:{width:"100%",padding:"14px",borderRadius:12,border:"none",cursor:"pointer",background:"linear-gradient(135deg,#dc2626,#b91c1c)",color:"#fff",fontSize:15,fontWeight:700,fontFamily:"inherit",boxShadow:"0 4px 14px rgba(220,38,38,0.3)"},
    btnWarn:{width:"100%",padding:"14px",borderRadius:12,border:"none",cursor:"pointer",background:"linear-gradient(135deg,#d97706,#b45309)",color:"#fff",fontSize:15,fontWeight:700,fontFamily:"inherit",boxShadow:"0 4px 14px rgba(217,119,6,0.25)"},
    btnInfo:{width:"100%",padding:"14px",borderRadius:12,border:"none",cursor:"pointer",background:"linear-gradient(135deg,#0891b2,#0e7490)",color:"#fff",fontSize:15,fontWeight:700,fontFamily:"inherit",boxShadow:"0 4px 14px rgba(8,145,178,0.25)"},
    label:{fontSize:11,color:C.textSub,fontWeight:600,letterSpacing:"0.06em",textTransform:"uppercase",marginBottom:6,display:"block"},
    sectionTitle:{fontSize:13,fontWeight:700,color:C.text,marginBottom:12},
    tag:(color,bg)=>({fontSize:11,color,background:bg,padding:"2px 10px",borderRadius:20,fontWeight:700,display:"inline-block"}),
  };
  const TABS=[["clock","打刻","🕐"],["history","履歴","📋"],["monthly","月次","📊"],["salary","給与","💴"],["staff","社員","👥"]];

  if(!loaded) return(
    <div style={{minHeight:"100vh",background:C.bg,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:12}}>
      <div style={{fontSize:40}}>⏱</div>
      <div style={{fontSize:16,color:C.primary,fontWeight:700}}>読み込み中...</div>
      <div style={{fontSize:12,color:C.textSub}}>Firebaseに接続しています</div>
    </div>
  );

  return (
    <div style={{minHeight:"100vh",background:C.bg,color:C.text,fontFamily:"'Noto Sans JP','Hiragino Kaku Gothic Pro','Helvetica Neue',sans-serif"}}>
      <div style={{background:`linear-gradient(135deg,${C.primary} 0%,${C.info} 100%)`,padding:"16px 20px 14px",display:"flex",alignItems:"center",gap:12,boxShadow:"0 4px 20px rgba(37,99,235,0.2)"}}>
        <div style={{width:38,height:38,borderRadius:12,background:"rgba(255,255,255,0.2)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:20}}>⏱</div>
        <div>
          <div style={{fontSize:17,fontWeight:800,color:"#fff"}}>勤怠管理システム</div>
          <div style={{fontSize:11,color:"rgba(255,255,255,0.7)"}}>Attendance Management</div>
        </div>
        <div style={{marginLeft:"auto",background:"rgba(255,255,255,0.15)",borderRadius:20,padding:"4px 12px",fontSize:12,color:"#fff",fontWeight:600}}>{employees.length}名登録</div>
      </div>

      <div style={{background:C.surface,borderBottom:`1px solid ${C.border}`,padding:"0 8px",display:"flex",overflowX:"auto"}}>
        {TABS.map(([k,l,icon])=>(
          <button key={k} onClick={()=>setTab(k)} style={{flex:"0 0 auto",padding:"12px 14px",border:"none",borderBottom:tab===k?`3px solid ${C.primary}`:"3px solid transparent",background:"transparent",cursor:"pointer",fontFamily:"inherit",fontSize:12,fontWeight:700,color:tab===k?C.primary:C.textSub,display:"flex",alignItems:"center",gap:4,whiteSpace:"nowrap"}}>
            {icon} {l}
          </button>
        ))}
      </div>

      <div style={{maxWidth:520,margin:"0 auto",padding:"16px 14px 48px",boxSizing:"border-box"}}>

        {tab==="clock"&&(
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            <div style={{...css.card,background:`linear-gradient(135deg,${C.primary},${C.info})`,border:"none",textAlign:"center",padding:"24px 20px"}}>
              <div style={{fontSize:12,color:"rgba(255,255,255,0.8)",marginBottom:2}}>{now.getFullYear()}年{now.getMonth()+1}月{now.getDate()}日({DAYS_JP[now.getDay()]})</div>
              <div style={{fontSize:48,fontWeight:900,color:"#fff",letterSpacing:"0.04em",fontVariantNumeric:"tabular-nums"}}>{now.toLocaleTimeString("ja-JP",{hour:"2-digit",minute:"2-digit",second:"2-digit"})}</div>
              {active&&<div style={{marginTop:12,display:"inline-flex",gap:20,background:"rgba(255,255,255,0.15)",padding:"8px 18px",borderRadius:12}}>
                <span style={{fontSize:12,color:"rgba(255,255,255,0.8)"}}>出勤 <b style={{color:"#fff"}}>{fmt.time(active.rec?.clockIn)}</b></span>
                <span style={{fontSize:12,color:"rgba(255,255,255,0.8)"}}>実働 <b style={{color:"#fff"}}>{fmt.mins(currWorkMins(selEmpId))}</b></span>
              </div>}
            </div>
            <div style={css.card}>
              <div style={css.sectionTitle}>社員を選択</div>
              {employees.length===0?<div style={{color:C.textMute,fontSize:13,textAlign:"center",padding:"20px 0"}}>「社員」タブで社員を追加してください</div>:(
                <div style={{display:"flex",flexDirection:"column",gap:8}}>
                  {employees.map(e=>{
                    const col=AVATAR_COLORS[e.colorIdx%AVATAR_COLORS.length];
                    const isSel=selEmpId===e.id;
                    const a=actives[String(e.id)];
                    return(
                      <button key={e.id} onClick={()=>{setSelEmpId(e.id);setStampNote("");}} style={{display:"flex",alignItems:"center",gap:12,padding:"10px 14px",background:isSel?C.primaryLight:"#fafcff",border:`1.5px solid ${isSel?C.primary:C.border}`,borderRadius:12,cursor:"pointer",textAlign:"left"}}>
                        <div style={{width:36,height:36,borderRadius:"50%",background:col,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:700,color:"#fff",flexShrink:0}}>{initials(e.name)}</div>
                        <div style={{flex:1}}><div style={{fontSize:14,fontWeight:700,color:C.text}}>{e.name}</div>{e.dept&&<div style={{fontSize:11,color:C.textSub}}>{e.dept}</div>}</div>
                        {a?<div style={{display:"flex",alignItems:"center",gap:5}}><div style={{width:7,height:7,borderRadius:"50%",background:a.breakStart?C.warn:C.success,boxShadow:`0 0 6px ${a.breakStart?C.warn:C.success}`}}/><span style={{fontSize:11,color:a.breakStart?C.warn:C.success,fontWeight:700}}>{a.breakStart?"休憩中":fmt.mins(currWorkMins(e.id))}</span></div>:<span style={{fontSize:11,color:C.textMute}}>未出勤</span>}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
            {selEmpId&&selEmp&&(
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                <div style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",background:C.primaryLight,borderRadius:12,border:`1px solid ${C.primaryMid}`}}>
                  <div style={{width:30,height:30,borderRadius:"50%",background:AVATAR_COLORS[selEmp.colorIdx%AVATAR_COLORS.length],display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:700,color:"#fff"}}>{initials(selEmp.name)}</div>
                  <span style={{fontSize:14,fontWeight:700,color:C.primary}}>{selEmp.name}</span>
                  {selEmp.dept&&<span style={{fontSize:12,color:C.textSub}}>/ {selEmp.dept}</span>}
                </div>
                {!active?<button onClick={doClockIn} style={css.btnSuccess}>🟢 出勤打刻</button>:(
                  <>{!isOnBreak?<button onClick={doBreakStart} style={css.btnWarn}>☕ 休憩開始</button>:<button onClick={doBreakEnd} style={css.btnInfo}>🔵 休憩終了</button>}
                  <input value={stampNote} onChange={e=>setStampNote(e.target.value)} placeholder="備考（任意）" style={css.input}/>
                  <button onClick={doClockOut} style={css.btnDanger}>🔴 退勤打刻</button></>
                )}
                <button onClick={()=>requirePw(()=>setCorrModal({mode:"new",empId:selEmpId}))} style={{padding:"10px",borderRadius:10,border:`1.5px solid ${C.borderMd}`,background:C.surface,color:C.textSub,fontSize:13,fontWeight:600,fontFamily:"inherit",cursor:"pointer"}}>📝 過去分入力・訂正</button>
              </div>
            )}
          </div>
        )}

        {tab==="history"&&(
          <div>
            <div style={{display:"flex",gap:8,marginBottom:14,alignItems:"center"}}>
              <select value={histFilter} onChange={e=>setHistFilter(e.target.value)} style={css.select}><option value="all">全社員</option>{employees.map(e=><option key={e.id} value={e.id}>{e.name}</option>)}</select>
              <button onClick={()=>requirePw(()=>setCorrModal({mode:"new",empId:histFilter==="all"?null:histFilter}))} style={{flexShrink:0,padding:"11px 14px",borderRadius:10,border:`1.5px solid ${C.primary}`,background:C.primaryLight,color:C.primary,fontSize:13,fontWeight:700,fontFamily:"inherit",cursor:"pointer",whiteSpace:"nowrap"}}>＋ 過去入力</button>
            </div>
            {histRecs.length===0?<div style={{textAlign:"center",padding:"60px 0",color:C.textMute,fontSize:14}}>打刻履歴がありません</div>:(
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                {histRecs.map(r=>{ const mins=workMins(r.clockIn,r.clockOut,r.breakMins); const e=employees.find(x=>x.id===r.empId); const col=e?AVATAR_COLORS[e.colorIdx%AVATAR_COLORS.length]:C.primary; return(
                  <div key={r.id} style={css.card}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:10,alignItems:"center"}}>
                      <div style={{display:"flex",alignItems:"center",gap:8}}>
                        <div style={{width:30,height:30,borderRadius:"50%",background:col,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700,color:"#fff"}}>{e?initials(e.name):"?"}</div>
                        <div><div style={{fontSize:13,fontWeight:700,color:C.text}}>{e?.name??"退職済み"}</div><div style={{fontSize:11,color:C.textSub}}>{r.date&&fmt.date(r.date)} {r.corrected&&<span style={{color:C.warn,fontSize:10}}>📝訂正</span>}</div></div>
                      </div>
                      <div style={{display:"flex",alignItems:"center",gap:8}}>
                        <span style={css.tag(C.success,"rgba(5,150,105,0.1)")}>{fmt.mins(mins)}</span>
                        <button onClick={()=>requirePw(()=>setCorrModal({mode:"edit",record:r}))} style={{background:C.primaryLight,border:`1px solid ${C.primaryMid}`,borderRadius:8,padding:"4px 10px",cursor:"pointer",color:C.primary,fontSize:11,fontWeight:700,fontFamily:"inherit"}}>訂正</button>
                      </div>
                    </div>
                    <div style={{display:"flex",gap:20}}>{[["出勤",fmt.time(r.clockIn)],["退勤",fmt.time(r.clockOut)],["休憩",fmt.mins(r.breakMins)]].map(([l,v])=><div key={l}><div style={{fontSize:10,color:C.textMute,marginBottom:2}}>{l}</div><div style={{fontSize:13,fontWeight:600,color:C.text}}>{v}</div></div>)}</div>
                    {r.note&&<div style={{marginTop:8,fontSize:12,color:C.textSub,background:C.surfaceAlt,borderRadius:8,padding:"6px 10px"}}>📝 {r.note}</div>}
                    {r.corrReason&&<div style={{marginTop:4,fontSize:11,color:C.warn}}>訂正理由: {r.corrReason}</div>}
                  </div>
                ); })}
              </div>
            )}
          </div>
        )}

        {tab==="monthly"&&(
          <div>
            <div style={{display:"flex",gap:8,marginBottom:16}}>
              <input type="month" value={selMonth} onChange={e=>setSelMonth(e.target.value)} style={{...css.input,flex:1}}/>
              <select value={monthEmpId} onChange={e=>setMonthEmpId(e.target.value)} style={{...css.select,flex:1}}><option value="all">全社員</option>{employees.map(e=><option key={e.id} value={e.id}>{e.name}</option>)}</select>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:14}}>
              {[["出勤日数",monthDays,"日",C.primary],["合計勤務",fmt.mins(monthTotal),"",C.success]].map(([l,v,u,c])=>(
                <div key={l} style={{...css.card,textAlign:"center",background:`linear-gradient(135deg,${c}15,${C.surface})`,borderColor:`${c}30`}}>
                  <div style={{fontSize:11,color:C.textSub,marginBottom:4}}>{l}</div><div style={{fontSize:30,fontWeight:800,color:c}}>{v}</div><div style={{fontSize:12,color:C.textSub}}>{u}</div>
                </div>
              ))}
            </div>
            {monthEmpId==="all"&&employees.length>0&&(
              <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:14}}>
                {employees.map(e=>{ const recs=records.filter(r=>r.empId===e.id&&r.date?.startsWith(selMonth)); const total=recs.reduce((a,r)=>a+workMins(r.clockIn,r.clockOut,r.breakMins),0); const days=new Set(recs.filter(r=>r.clockOut).map(r=>r.date)).size; return(
                  <div key={e.id} style={{...css.card,display:"flex",alignItems:"center",gap:12}}>
                    <div style={{width:34,height:34,borderRadius:"50%",background:AVATAR_COLORS[e.colorIdx%AVATAR_COLORS.length],display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,fontWeight:700,color:"#fff",flexShrink:0}}>{initials(e.name)}</div>
                    <div style={{flex:1}}><div style={{fontSize:14,fontWeight:700}}>{e.name}</div>{e.dept&&<div style={{fontSize:11,color:C.textSub}}>{e.dept}</div>}</div>
                    <div style={{textAlign:"right"}}><div style={{fontSize:15,fontWeight:700,color:C.success}}>{fmt.mins(total)}</div><div style={{fontSize:11,color:C.textSub}}>{days}日出勤</div></div>
                  </div>
                ); })}
              </div>
            )}
            {monthRecs.length===0?<div style={{textAlign:"center",padding:"40px 0",color:C.textMute,fontSize:14}}>この月のデータはありません</div>:(
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {monthRecs.map(r=>{ const mins=workMins(r.clockIn,r.clockOut,r.breakMins); const e=employees.find(x=>x.id===r.empId); return(
                  <div key={r.id} style={{...css.card,display:"flex",justifyContent:"space-between",alignItems:"center",padding:"12px 16px"}}>
                    <div><div style={{fontSize:13,fontWeight:700}}>{r.date&&fmt.date(r.date)}</div>{monthEmpId==="all"&&<div style={{fontSize:11,color:C.textSub}}>{e?.name}</div>}</div>
                    <div style={{display:"flex",gap:10,alignItems:"center"}}><span style={{fontSize:12,color:C.textSub}}>{fmt.time(r.clockIn)}〜{fmt.time(r.clockOut)}</span><span style={css.tag(C.success,"rgba(5,150,105,0.1)")}>{fmt.mins(mins)}</span></div>
                  </div>
                ); })}
              </div>
            )}
          </div>
        )}

        {tab==="salary"&&(
          <div>
            <div style={{...css.card,marginBottom:14}}>
              <div style={css.sectionTitle}>💴 給与自動計算（AI）</div>
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                <div><label style={css.label}>対象月</label><input type="month" value={salMonth} onChange={e=>{setSalMonth(e.target.value);setSalResult(null);}} style={css.input}/></div>
                <div><label style={css.label}>社員</label><select value={salEmpId||""} onChange={e=>{setSalEmpId(e.target.value||null);setSalResult(null);}} style={css.select}><option value="">選択してください</option>{employees.map(e=><option key={e.id} value={e.id}>{e.name}{e.dept?` / ${e.dept}`:""}</option>)}</select></div>
                {salEmpId&&(()=>{ const e=employees.find(x=>x.id===salEmpId); return e&&<div style={{background:C.primaryLight,borderRadius:10,padding:"10px 14px",fontSize:12,color:C.primary,display:"flex",gap:16,flexWrap:"wrap"}}><span>基本給: <b>{fmt.yen(e.basicSalary)}</b></span><span>時給: <b>{fmt.yen(e.hourlyRate)}</b></span><span>扶養: <b>{e.dependents}人</b></span></div>; })()}
                {salError&&<div style={{fontSize:12,color:C.danger,background:"rgba(220,38,38,0.05)",borderRadius:8,padding:"8px 12px"}}>{salError}</div>}
                <button onClick={calcSalary} disabled={salLoading} style={{...css.btnPrimary,opacity:salLoading?0.7:1}}>{salLoading?"⏳ AI計算中...":"🤖 AIで給与計算する"}</button>
              </div>
            </div>
            {salResult&&(
              <div style={{...css.card,border:`2px solid ${C.primary}30`}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
                  <div><div style={{fontSize:15,fontWeight:800,color:C.text}}>{salResult.empName}</div><div style={{fontSize:12,color:C.textSub}}>{salMonth} 給与明細</div></div>
                  <div style={{textAlign:"right"}}><div style={{fontSize:11,color:C.textSub}}>手取り</div><div style={{fontSize:24,fontWeight:900,color:C.primary}}>{fmt.yen(salResult.netSalary)}</div></div>
                </div>
                <div style={{background:C.surfaceAlt,borderRadius:10,padding:"10px 14px",marginBottom:14,display:"flex",gap:16,flexWrap:"wrap"}}>
                  <span style={{fontSize:12,color:C.textSub}}>出勤 <b style={{color:C.text}}>{salResult.workDays}日</b></span>
                  <span style={{fontSize:12,color:C.textSub}}>総労働 <b style={{color:C.text}}>{salResult.totalHours}</b></span>
                  <span style={{fontSize:12,color:C.textSub}}>残業 <b style={{color:C.warn}}>{salResult.overtimeHours}h</b></span>
                </div>
                <div style={{marginBottom:12}}>
                  <div style={{fontSize:12,fontWeight:700,color:C.success,marginBottom:6}}>【支給】</div>
                  {[["基本給",salResult.grossSalary-salResult.overtimePay],["残業代",salResult.overtimePay]].map(([l,v])=><div key={l} style={{display:"flex",justifyContent:"space-between",padding:"5px 0",borderBottom:`1px solid ${C.border}`}}><span style={{fontSize:13,color:C.textSub}}>{l}</span><span style={{fontSize:13,fontWeight:600,color:C.text}}>{fmt.yen(v)}</span></div>)}
                  <div style={{display:"flex",justifyContent:"space-between",padding:"7px 8px",background:C.surfaceAlt,borderRadius:8,marginTop:4}}><span style={{fontSize:13,fontWeight:700,color:C.success}}>総支給額</span><span style={{fontSize:14,fontWeight:800,color:C.success}}>{fmt.yen(salResult.grossSalary)}</span></div>
                </div>
                <div style={{marginBottom:12}}>
                  <div style={{fontSize:12,fontWeight:700,color:C.danger,marginBottom:6}}>【控除】</div>
                  {[["健康保険料",salResult.healthInsurance],["厚生年金",salResult.pensionInsurance],["雇用保険",salResult.employmentInsurance],["所得税",salResult.incomeTax],["住民税（概算）",salResult.residentTax]].map(([l,v])=><div key={l} style={{display:"flex",justifyContent:"space-between",padding:"5px 0",borderBottom:`1px solid ${C.border}`}}><span style={{fontSize:13,color:C.textSub}}>{l}</span><span style={{fontSize:13,fontWeight:600,color:C.text}}>▲{fmt.yen(v)}</span></div>)}
                  <div style={{display:"flex",justifyContent:"space-between",padding:"7px 8px",background:"rgba(220,38,38,0.04)",borderRadius:8,marginTop:4}}><span style={{fontSize:13,fontWeight:700,color:C.danger}}>控除合計</span><span style={{fontSize:14,fontWeight:800,color:C.danger}}>▲{fmt.yen(salResult.totalDeduction)}</span></div>
                </div>
                <div style={{background:`linear-gradient(135deg,${C.primary},${C.info})`,borderRadius:12,padding:"14px 18px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <span style={{fontSize:15,fontWeight:700,color:"#fff"}}>💴 差引支給額（手取り）</span>
                  <span style={{fontSize:22,fontWeight:900,color:"#fff"}}>{fmt.yen(salResult.netSalary)}</span>
                </div>
                {salResult.memo&&<div style={{marginTop:10,fontSize:11,color:C.textSub,background:C.surfaceAlt,borderRadius:8,padding:"8px 12px"}}>📌 {salResult.memo}</div>}
                <div style={{marginTop:8,fontSize:10,color:C.textMute}}>※ この計算は概算です。実際の給与計算は税理士等にご確認ください。</div>
              </div>
            )}
          </div>
        )}

        {tab==="staff"&&(
          <div>
            <div style={{...css.card,marginBottom:16}}>
              <div style={css.sectionTitle}>＋ 社員を追加</div>
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                  <div><label style={css.label}>名前 *</label><input value={newEmp.name} onChange={e=>setNewEmp({...newEmp,name:e.target.value})} placeholder="山田 太郎" style={css.input}/></div>
                  <div><label style={css.label}>部署・役職</label><input value={newEmp.dept} onChange={e=>setNewEmp({...newEmp,dept:e.target.value})} placeholder="営業部" style={css.input}/></div>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                  <div><label style={css.label}>基本給（円）</label><input type="number" value={newEmp.basicSalary} onChange={e=>setNewEmp({...newEmp,basicSalary:e.target.value})} placeholder="250000" style={css.input}/></div>
                  <div><label style={css.label}>時給（円）</label><input type="number" value={newEmp.hourlyRate} onChange={e=>setNewEmp({...newEmp,hourlyRate:e.target.value})} placeholder="自動計算" style={css.input}/></div>
                </div>
                <div><label style={css.label}>扶養人数</label><select value={newEmp.dependents} onChange={e=>setNewEmp({...newEmp,dependents:e.target.value})} style={css.select}>{[0,1,2,3,4,5,6].map(n=><option key={n} value={n}>{n}人{n===0?" (なし)":""}</option>)}</select></div>
                {empError&&<div style={{fontSize:12,color:C.danger}}>{empError}</div>}
                <button onClick={addEmployee} style={css.btnPrimary}>追加する</button>
              </div>
            </div>
            {employees.length===0?<div style={{textAlign:"center",padding:"40px 0",color:C.textMute,fontSize:14}}>まだ社員が登録されていません</div>:(
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                {employees.map(e=>{ const col=AVATAR_COLORS[e.colorIdx%AVATAR_COLORS.length]; const a=actives[String(e.id)]; const isEditing=editingEmp?.id===e.id; return(
                  <div key={e.id} style={css.card}>
                    {!isEditing?(
                      <>
                        <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:10}}>
                          <div style={{width:42,height:42,borderRadius:"50%",background:col,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,fontWeight:700,color:"#fff",flexShrink:0}}>{initials(e.name)}</div>
                          <div style={{flex:1}}>
                            <div style={{fontSize:15,fontWeight:700,color:C.text}}>{e.name}</div>
                            <div style={{display:"flex",gap:6,alignItems:"center",flexWrap:"wrap",marginTop:2}}>
                              {e.dept&&<span style={{fontSize:12,color:C.textSub}}>{e.dept}</span>}
                              {a&&<span style={{...css.tag(a.breakStart?C.warn:C.success,a.breakStart?"rgba(217,119,6,0.1)":"rgba(5,150,105,0.1)")}}>{a.breakStart?"休憩中":"勤務中"}</span>}
                            </div>
                          </div>
                          <div style={{display:"flex",gap:6}}>
                            <button onClick={()=>setEditingEmp({...e})} style={{background:C.primaryLight,border:`1px solid ${C.primaryMid}`,borderRadius:8,padding:"5px 10px",cursor:"pointer",color:C.primary,fontSize:11,fontWeight:700,fontFamily:"inherit"}}>編集</button>
                            <button onClick={()=>removeEmployee(e.id)} style={{background:"rgba(220,38,38,0.08)",border:"1px solid rgba(220,38,38,0.2)",borderRadius:8,padding:"5px 10px",cursor:"pointer",color:C.danger,fontSize:11,fontWeight:700,fontFamily:"inherit"}}>削除</button>
                          </div>
                        </div>
                        <div style={{display:"flex",gap:12,flexWrap:"wrap",background:C.surfaceAlt,borderRadius:8,padding:"8px 12px"}}>
                          <span style={{fontSize:12,color:C.textSub}}>基本給 <b style={{color:C.text}}>{fmt.yen(e.basicSalary)}</b></span>
                          <span style={{fontSize:12,color:C.textSub}}>時給 <b style={{color:C.text}}>{fmt.yen(e.hourlyRate)}</b></span>
                          <span style={{fontSize:12,color:C.textSub}}>扶養 <b style={{color:C.text}}>{e.dependents}人</b></span>
                        </div>
                      </>
                    ):(
                      <div style={{display:"flex",flexDirection:"column",gap:8}}>
                        <div style={{fontSize:13,fontWeight:700,color:C.primary,marginBottom:4}}>✏️ {e.name} を編集</div>
                        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                          <div><label style={css.label}>名前</label><input value={editingEmp.name} onChange={ev=>setEditingEmp({...editingEmp,name:ev.target.value})} style={css.input}/></div>
                          <div><label style={css.label}>部署</label><input value={editingEmp.dept} onChange={ev=>setEditingEmp({...editingEmp,dept:ev.target.value})} style={css.input}/></div>
                        </div>
                        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                          <div><label style={css.label}>基本給</label><input type="number" value={editingEmp.basicSalary} onChange={ev=>setEditingEmp({...editingEmp,basicSalary:ev.target.value})} style={css.input}/></div>
                          <div><label style={css.label}>時給</label><input type="number" value={editingEmp.hourlyRate} onChange={ev=>setEditingEmp({...editingEmp,hourlyRate:ev.target.value})} style={css.input}/></div>
                        </div>
                        <div><label style={css.label}>扶養人数</label><select value={editingEmp.dependents} onChange={ev=>setEditingEmp({...editingEmp,dependents:ev.target.value})} style={css.select}>{[0,1,2,3,4,5,6].map(n=><option key={n} value={n}>{n}人</option>)}</select></div>
                        <div style={{display:"flex",gap:8}}>
                          <button onClick={saveEditEmp} style={{...css.btnPrimary,flex:1}}>保存</button>
                          <button onClick={()=>setEditingEmp(null)} style={{flex:1,padding:"14px",borderRadius:12,border:`1.5px solid ${C.border}`,background:C.surface,color:C.textSub,fontFamily:"inherit",fontSize:14,fontWeight:700,cursor:"pointer"}}>キャンセル</button>
                        </div>
                      </div>
                    )}
                  </div>
                ); })}
              </div>
            )}
          </div>
        )}
      </div>

      {pwModal&&(
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.4)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:100,padding:20}}>
          <div style={{background:C.surface,borderRadius:20,padding:"28px 24px",width:"100%",maxWidth:360,boxShadow:"0 20px 60px rgba(0,0,0,0.15)"}}>
            <div style={{fontSize:16,fontWeight:800,color:C.text,marginBottom:6}}>🔒 管理者パスワード</div>
            <div style={{fontSize:13,color:C.textSub,marginBottom:16}}>この操作には管理者パスワードが必要です</div>
            <input type="password" value={pwInput} onChange={e=>{setPwInput(e.target.value);setPwError("");}} onKeyDown={e=>e.key==="Enter"&&confirmPw()} placeholder="パスワードを入力" style={{...css.input,marginBottom:8}} autoFocus/>
            {pwError&&<div style={{fontSize:12,color:C.danger,marginBottom:8}}>{pwError}</div>}
            <div style={{display:"flex",gap:8,marginTop:4}}>
              <button onClick={confirmPw} style={{...css.btnPrimary,flex:1}}>確認</button>
              <button onClick={()=>setPwModal(null)} style={{flex:1,padding:"14px",borderRadius:12,border:`1.5px solid ${C.border}`,background:C.surface,color:C.textSub,fontFamily:"inherit",fontSize:14,fontWeight:700,cursor:"pointer"}}>キャンセル</button>
            </div>
            <div style={{marginTop:12,fontSize:11,color:C.textMute,textAlign:"center"}}>デフォルト: 1234</div>
          </div>
        </div>
      )}

      {corrModal&&<CorrectionModal modal={corrModal} employees={employees} css={css} C={C} onSave={saveCorrected} onClose={()=>setCorrModal(null)}/>}
    </div>
  );
}

function CorrectionModal({modal,employees,css,C,onSave,onClose}){
  const isEdit=modal.mode==="edit"&&modal.record;
  const rec=isEdit?modal.record:null;
  function toTimeStr(iso){ if(!iso)return""; const d=new Date(iso); return `${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`; }
  const [empId,setEmpId]=useState(rec?.empId||modal.empId||(employees[0]?.id)||"");
  const [date,setDate]=useState(rec?.date||new Date().toISOString().slice(0,10));
  const [clockIn,setClockIn]=useState(toTimeStr(rec?.clockIn)||"09:00");
  const [clockOut,setClockOut]=useState(toTimeStr(rec?.clockOut)||"18:00");
  const [breakMins,setBreakMins]=useState(rec?.breakMins??60);
  const [note,setNote]=useState(rec?.note||"");
  const [corrReason,setCorrReason]=useState(rec?.corrReason||"");
  const [error,setError]=useState("");
  function save(){
    if(!empId){setError("社員を選択してください");return;}
    if(!corrReason.trim()){setError("訂正理由・補足を入力してください");return;}
    const ci=new Date(`${date}T${clockIn}:00`).toISOString();
    const co=new Date(`${date}T${clockOut}:00`).toISOString();
    if(new Date(co)<=new Date(ci)){setError("退勤は出勤より後にしてください");return;}
    onSave({id:rec?.id||null,empId,date,clockIn:ci,clockOut:co,breakMins:parseInt(breakMins)||0,note,corrReason,corrected:true});
  }
  return(
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.4)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:100,padding:16,overflowY:"auto"}}>
      <div style={{background:C.surface,borderRadius:20,padding:"24px 20px",width:"100%",maxWidth:400,boxShadow:"0 20px 60px rgba(0,0,0,0.15)",maxHeight:"90vh",overflowY:"auto"}}>
        <div style={{fontSize:16,fontWeight:800,color:C.text,marginBottom:4}}>{isEdit?"📝 打刻を訂正":"📋 過去分を入力"}</div>
        <div style={{fontSize:12,color:C.textSub,marginBottom:18}}>訂正理由の入力が必須です</div>
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <div><label style={css.label}>社員</label><select value={empId} onChange={e=>setEmpId(e.target.value)} style={css.select} disabled={isEdit}><option value="">選択...</option>{employees.map(e=><option key={e.id} value={e.id}>{e.name}</option>)}</select></div>
          <div><label style={css.label}>日付</label><input type="date" value={date} onChange={e=>setDate(e.target.value)} style={css.input}/></div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            <div><label style={css.label}>出勤時刻</label><input type="time" value={clockIn} onChange={e=>setClockIn(e.target.value)} style={css.input}/></div>
            <div><label style={css.label}>退勤時刻</label><input type="time" value={clockOut} onChange={e=>setClockOut(e.target.value)} style={css.input}/></div>
          </div>
          <div><label style={css.label}>休憩（分）</label><input type="number" value={breakMins} onChange={e=>setBreakMins(e.target.value)} style={css.input}/></div>
          <div><label style={css.label}>備考</label><input value={note} onChange={e=>setNote(e.target.value)} placeholder="任意" style={css.input}/></div>
          <div><label style={{...css.label,color:C.danger}}>訂正理由・補足 *</label><textarea value={corrReason} onChange={e=>setCorrReason(e.target.value)} placeholder="例：打刻忘れのため上長承認済み" rows={3} style={{...css.input,resize:"vertical",lineHeight:1.5}}/></div>
          {error&&<div style={{fontSize:12,color:C.danger,background:"rgba(220,38,38,0.05)",borderRadius:8,padding:"8px 12px"}}>{error}</div>}
          <div style={{display:"flex",gap:8}}>
            <button onClick={save} style={{...css.btnPrimary,flex:1}}>保存する</button>
            <button onClick={onClose} style={{flex:1,padding:"14px",borderRadius:12,border:`1.5px solid ${C.border}`,background:C.surface,color:C.textSub,fontFamily:"inherit",fontSize:14,fontWeight:700,cursor:"pointer"}}>キャンセル</button>
          </div>
        </div>
      </div>
    </div>
  );
}

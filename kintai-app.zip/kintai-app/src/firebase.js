// src/firebase.js
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyB2-wjlwWrlW8GNDjwq6BNZMr3NI55kbcQ",
  authDomain: "kintai-app-9b12a.firebaseapp.com",
  projectId: "kintai-app-9b12a",
  storageBucket: "kintai-app-9b12a.firebasestorage.app",
  messagingSenderId: "499695157057",
  appId: "1:499695157057:web:54df4228e9f797d09fabc0"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
